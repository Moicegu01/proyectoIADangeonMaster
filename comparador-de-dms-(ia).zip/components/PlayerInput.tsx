import React, { useState } from 'react';

interface PlayerInputProps {
  onSend: (action: string) => void;
  isLoading: boolean;
}

export function PlayerInput({ onSend, isLoading }: PlayerInputProps) {
  const [action, setAction] = useState('');

  const handleSend = () => {
    if (action.trim() && !isLoading) {
      onSend(action.trim());
      setAction('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="pt-4 border-t-4 border-double border-[#7B4B2A]/50 flex items-center space-x-4">
      <input
        type="text"
        value={action}
        onChange={(e) => setAction(e.target.value)}
        onKeyPress={handleKeyPress}
        placeholder="Escribe tu siguiente acción..."
        className="flex-grow bg-[#EAE0C8] border border-[#D1C6AD] rounded-md p-3 text-black focus:ring-2 focus:ring-[#7B4B2A] focus:outline-none transition-shadow shadow-inner disabled:opacity-60"
        disabled={isLoading}
      />
      <button
        onClick={handleSend}
        disabled={isLoading || !action.trim()}
        className="bg-[#7B4B2A] hover:bg-[#5C4033] text-[#D4AF37] font-bold py-3 px-6 rounded-lg border border-[#D4AF37]/50 shadow-lg transition-all duration-200 disabled:bg-[#7B4B2A]/50 disabled:text-[#D4AF37]/50 disabled:cursor-not-allowed"
      >
        {isLoading ? 'Escribiendo...' : 'Decretar'}
      </button>
    </div>
  );
}