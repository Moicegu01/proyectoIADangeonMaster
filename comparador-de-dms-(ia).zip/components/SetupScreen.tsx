import React, { useState } from 'react';

interface SetupScreenProps {
  onStart: (systemPrompt: string) => void;
}

const defaultPrompt = "Eres un Dungeon Master para una partida de Dungeons & Dragons. La aventura comienza en una taberna oscura y bulliciosa. El personaje del jugador se llama Kaelen. Tu objetivo es crear una narrativa vívida, atractiva y coherente. Describe la escena en detalle y luego espera la acción de Kaelen.";

export function SetupScreen({ onStart }: SetupScreenProps) {
  const [prompt, setPrompt] = useState(defaultPrompt);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onStart(prompt.trim());
    }
  };

  return (
    <div className="flex-grow flex items-center justify-center">
      <div className="w-full max-w-3xl parchment p-8">
        <h2 className="text-4xl font-bold text-[#7B4B2A] mb-6 text-center font-['Cinzel_Decorative']">
          El Prólogo
        </h2>
        <p className="mb-6 text-center italic">
          Define el edicto inicial que guiará a los narradores de IA. Este será el fundamento de la crónica que está por escribirse.
        </p>
        <form onSubmit={handleSubmit}>
          <label htmlFor="system-prompt" className="block text-[#7B4B2A] text-sm font-bold mb-2">
            Edicto del Sistema
          </label>
          <textarea
            id="system-prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full h-48 p-3 bg-[#EAE0C8] border border-[#D1C6AD] rounded-md text-black focus:ring-2 focus:ring-[#7B4B2A] focus:outline-none transition-shadow shadow-inner"
            placeholder="Ej: Eres un Dungeon Master..."
          />
          <button
            type="submit"
            className="w-full mt-6 bg-[#7B4B2A] hover:bg-[#5C4033] text-[#D4AF37] font-bold py-3 px-4 rounded-lg text-lg border border-[#D4AF37]/50 shadow-lg transition-all duration-200 disabled:bg-[#7B4B2A]/50 disabled:text-[#D4AF37]/50 disabled:cursor-not-allowed"
            disabled={!prompt.trim()}
          >
            Comenzar la Aventura
          </button>
        </form>
      </div>
    </div>
  );
}