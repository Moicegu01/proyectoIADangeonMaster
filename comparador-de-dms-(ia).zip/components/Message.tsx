import React from 'react';
import { Message as MessageType } from '../types';

interface MessageProps {
  message: MessageType;
}

export const MessageComponent: React.FC<MessageProps> = ({ message }) => {
  const isUser = message.role === 'user';
  const messageText = message.parts.map(part => part.text).join('\n');
  
  const containerClasses = isUser ? 'flex justify-end' : 'flex justify-start';
  
  // Model messages look like they're written on the scroll itself.
  // User messages have a subtle, different background to distinguish them.
  const bubbleClasses = isUser
    ? 'bg-[#D1C6AD] shadow-sm rounded-lg' // A faded, slightly different parchment for user
    : ''; // No background for the model, it's part of the scroll

  return (
    <div className={containerClasses}>
      <div className={`p-4 max-w-xl ${bubbleClasses}`}>
        <p className="whitespace-pre-wrap leading-relaxed">{messageText}</p>
      </div>
    </div>
  );
};