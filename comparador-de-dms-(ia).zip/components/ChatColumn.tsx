import React, { useRef, useEffect } from 'react';
import { Message as MessageType } from '../types';
import { MessageComponent } from './Message';
import { LoadingSpinner } from './LoadingSpinner';

interface ChatColumnProps {
  title: string;
  messages: MessageType[];
  isLoading: boolean;
}

export function ChatColumn({ title, messages, isLoading }: ChatColumnProps) {
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="parchment flex flex-col h-full overflow-hidden">
      <h3 className="text-2xl font-bold text-[#7B4B2A] p-4 border-b-2 border-[#7B4B2A]/50 sticky top-0 bg-[#EAE0C8]/80 backdrop-blur-sm z-10 text-center font-['Cinzel_Decorative']">
        {title}
      </h3>
      <div className="flex-grow p-4 overflow-y-auto">
        <div className="space-y-4">
          {messages.map((msg, index) => (
            <MessageComponent key={index} message={msg} />
          ))}
          {isLoading && messages[messages.length - 1]?.role === 'user' && (
            <div className="flex justify-start">
                <div className="flex items-center space-x-2 p-4">
                    <LoadingSpinner />
                    <span className="italic">El narrador delibera...</span>
                </div>
            </div>
          )}
          <div ref={endOfMessagesRef} />
        </div>
      </div>
    </div>
  );
}