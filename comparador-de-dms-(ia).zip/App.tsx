import React, { useState, useCallback } from 'react';
import { Chat } from '@google/genai';
import { SetupScreen } from './components/SetupScreen';
import { GameScreen } from './components/GameScreen';
import { startChatSession } from './services/geminiService';
import { Message } from './types';

type GamePhase = 'setup' | 'playing';

export default function App() {
  const [gamePhase, setGamePhase] = useState<GamePhase>('setup');
  const [historyDM1, setHistoryDM1] = useState<Message[]>([]);
  const [historyDM2, setHistoryDM2] = useState<Message[]>([]);
  const [chatDM1, setChatDM1] = useState<Chat | null>(null);
  const [chatDM2, setChatDM2] = useState<Chat | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStartGame = (systemPrompt: string) => {
    try {
      const initialHistory: Message[] = [];
      const dm1Session = startChatSession('gemini-2.5-flash', systemPrompt, initialHistory);
      const dm2Session = startChatSession('gemini-2.5-pro', systemPrompt, initialHistory);
      setChatDM1(dm1Session);
      setChatDM2(dm2Session);
      setHistoryDM1([]);
      setHistoryDM2([]);
      setGamePhase('playing');
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Ocurrió un error desconocido durante la configuración.');
      console.error(e);
    }
  };

  const handleSendAction = useCallback(async (action: string) => {
    if (!chatDM1 || !chatDM2 || isLoading) return;

    setIsLoading(true);
    setError(null);

    const userMessage: Message = {
      role: 'user',
      parts: [{ text: action }],
    };

    setHistoryDM1(prev => [...prev, userMessage]);
    setHistoryDM2(prev => [...prev, userMessage]);

    try {
      const [responseDM1, responseDM2] = await Promise.all([
        chatDM1.sendMessage({ message: action }),
        chatDM2.sendMessage({ message: action })
      ]);

      const modelMessageDM1: Message = {
        role: 'model',
        parts: [{ text: responseDM1.text }],
      };
      const modelMessageDM2: Message = {
        role: 'model',
        parts: [{ text: responseDM2.text }],
      };

      setHistoryDM1(prev => [...prev, modelMessageDM1]);
      setHistoryDM2(prev => [...prev, modelMessageDM2]);

    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'Ocurrió un error en la API.';
      setError(errorMessage);
      console.error(e);
       const errorResponseMessage: Message = {
         role: 'model',
         parts: [{ text: `Lo siento, ocurrió un error: ${errorMessage}` }]
       };
       setHistoryDM1(prev => [...prev.slice(0, -1), errorResponseMessage]);
       setHistoryDM2(prev => [...prev.slice(0, -1), errorResponseMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [chatDM1, chatDM2, isLoading]);

  const handleReset = () => {
    setGamePhase('setup');
    setHistoryDM1([]);
    setHistoryDM2([]);
    setChatDM1(null);
    setChatDM2(null);
    setIsLoading(false);
    setError(null);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="p-4 flex justify-between items-center border-b-4 border-double border-[#7B4B2A]/50">
        <h1 className="text-3xl font-bold text-[#7B4B2A] font-['Cinzel_Decorative'] tracking-wider">
          Comparador de DMs (IA)
        </h1>
        {gamePhase === 'playing' && (
          <button
            onClick={handleReset}
            className="bg-[#7B4B2A] hover:bg-[#5C4033] text-[#D4AF37] font-bold py-2 px-5 rounded-md border border-[#D4AF37]/50 shadow-md transition-all duration-200"
          >
            Nueva Comparación
          </button>
        )}
      </header>
      <main className="flex-grow p-4 md:p-6 lg:p-8 flex flex-col">
        {error && (
            <div className="bg-[#DC143C]/20 border-2 border-double border-[#DC143C] text-black px-4 py-3 rounded-md relative mb-4 shadow-inner" role="alert">
                <strong className="font-bold">Error en la Trama: </strong>
                <span className="block sm:inline">{error}</span>
            </div>
        )}
        {gamePhase === 'setup' ? (
          <SetupScreen onStart={handleStartGame} />
        ) : (
          <GameScreen
            historyDM1={historyDM1}
            historyDM2={historyDM2}
            onSendAction={handleSendAction}
            isLoading={isLoading}
          />
        )}
      </main>
    </div>
  );
}